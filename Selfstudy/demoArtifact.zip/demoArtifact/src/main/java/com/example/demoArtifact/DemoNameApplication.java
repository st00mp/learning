package com.example.demoArtifact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoNameApplication.class, args);
	}

}
